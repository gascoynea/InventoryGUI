package com.example.projectc482.controller;

import com.example.projectc482.Model.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
// class used to modify products in the products class
public class ModifyProductFormController implements Initializable {
    public AnchorPane ModifyProductFormMainWindow;
    public TextField ModifyProductFormMainTFID;
    public TextField ModifyProductFormMainTFName;
    public TextField ModifyProductFormMainTFInv;
    public TextField ModifyProductFormMainTFPrice;
    public TextField ModifyProductFormMainTFMax;
    public TextField ModifyProductFormMainTFMin;
    public TextField ModifyProductFormMainSearchPartIDName;
    public Button ModifyProductFormButtonCacncel;
    public Button ModifyProductFormButtonSave;
    public Button ModifyProductFormButtonRemovePart;
    public Button ModifyProductFormButtonAdd;
    public TableView ModifyProductFormAddTable;
    public TableColumn ModifyProductFormAddTablePartID;
    public TableColumn ModifyProductFormAddTablePartName;
    public TableColumn ModifyProductFormAddTableInvLevel;
    public TableColumn ModifyProductFormAddTablePriceCostperUnit;
    public TableView ModifyProductFormRemovePartTable;
    public TableColumn ModifyProductFormRemovePartTablePartID;
    public TableColumn ModifyProductFormRemovePartTablePartName;
    public TableColumn ModifyProductFormRemovePartTableInvLevel;
    public TableColumn ModifyProductFormRemovePartTablePriceCostperUnit;
    public Label ModifyProductFormMainLabel;
    public Label ModifyProductFormLabelID;
    public Label ModifyProductFormLabelName;
    public Label ModifyProductFormLabelInventory;
    public Label ModifyProductFormLabelPrice;
    public Label ModifyProductFormLabelMax;
    public Label ModifyProductFormLabelMin;
    //data structures used to modify products
    public Product selectedProductModify;
    public ObservableList<Part> partsInProduct = FXCollections.observableArrayList();
    public ObservableList<Part> partsInProductOriginal = FXCollections.observableArrayList();;
    public Product original = new Product(0," ", 0,0,0,0);
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        }
    //sets original values of the selected product to the correct fields also sets the tables with all parts and the associated part table with all associated parts
    public void setProductToModify(Product selectedProductModify) {
        //gets associated parts
        this.selectedProductModify = selectedProductModify;
        partsInProduct = selectedProductModify.getPartsInProduct();
        original = selectedProductModify;
        partsInProductOriginal.addAll(partsInProduct);
        //setting text fields
        int id = selectedProductModify.getId();
        String name = selectedProductModify.getName();
        int inventory = selectedProductModify.getStock();
        Double price = selectedProductModify.getPrice();
        int max = selectedProductModify.getMax();
        int min = selectedProductModify.getMin();
        ModifyProductFormMainTFID.setText(String.valueOf(id));
        ModifyProductFormMainTFInv.setText(String.valueOf(inventory));
        ModifyProductFormMainTFMin.setText(String.valueOf(min));
        ModifyProductFormMainTFMax.setText(String.valueOf(max));
        ModifyProductFormMainTFName.setText(name);
        ModifyProductFormMainTFPrice.setText(String.valueOf(price));
        //populates part table with all available parts
        ModifyProductFormAddTable.setItems(Inventory.getPartInventory());
        ModifyProductFormAddTablePartID.setCellValueFactory(new PropertyValueFactory<>("id"));
        ModifyProductFormAddTablePartName.setCellValueFactory(new PropertyValueFactory<>("name"));
        ModifyProductFormAddTableInvLevel.setCellValueFactory(new PropertyValueFactory<>("stock"));
        ModifyProductFormAddTablePriceCostperUnit.setCellValueFactory(new PropertyValueFactory<>("price"));
        //populates associated parts with parts in partsInProduct list
        ModifyProductFormRemovePartTable.setItems(partsInProduct);
        ModifyProductFormRemovePartTablePartID.setCellValueFactory(new PropertyValueFactory<>("id"));
        ModifyProductFormRemovePartTablePartName.setCellValueFactory(new PropertyValueFactory<>("name"));
        ModifyProductFormRemovePartTableInvLevel.setCellValueFactory(new PropertyValueFactory<>("stock"));
        ModifyProductFormRemovePartTablePriceCostperUnit.setCellValueFactory(new PropertyValueFactory<>("price"));
    }
    //uses the search parts method in Inventory to repopulate the part table with search results
    public void OnSearchPartIDName(ActionEvent actionEvent) {
        String searchedPart = ModifyProductFormMainSearchPartIDName.getText();
        ObservableList partsFound = Inventory.searchParts(searchedPart);
        ModifyProductFormAddTable.setItems(partsFound);
    }
    //Throws error message if no part is clicked
    //If part selected adds it to the associated parts table and also to the parts in products list
    public void OnAddButtonClick(ActionEvent actionEvent) {
        Part partAssociated = (Part) ModifyProductFormAddTable.getSelectionModel().getSelectedItem();
        if (partAssociated != null) {
            partsInProduct.add(partAssociated);
            ModifyProductFormRemovePartTable.setItems(partsInProduct);
            ModifyProductFormRemovePartTablePartID.setCellValueFactory(new PropertyValueFactory<>("id"));
            ModifyProductFormRemovePartTablePartName.setCellValueFactory(new PropertyValueFactory<>("name"));
            ModifyProductFormRemovePartTableInvLevel.setCellValueFactory(new PropertyValueFactory<>("stock"));
            ModifyProductFormRemovePartTablePriceCostperUnit.setCellValueFactory(new PropertyValueFactory<>("price"));
        }
        else{
            System.out.println("Please select a Part to add.");
        }
    }
    //Removes associated part form the table and the parts in product list
    public void OnRemoveButtonClick(ActionEvent actionEvent) {
        Part partToRemove = (Part) ModifyProductFormRemovePartTable.getSelectionModel().getSelectedItem();
        if (partToRemove != null) {
            partsInProduct.remove(partToRemove);
            ModifyProductFormRemovePartTable.setItems(partsInProduct);
        }
        else{
            System.out.println("No part selected to remove.");
        }
    }
    //resets list in the selected products associated parts in products list.
    //Also, closes modify parts window and opens main controller window
    public void OnCancelButtonClick(ActionEvent actionEvent) throws IOException {
        partsInProduct = partsInProductOriginal;
        selectedProductModify.setPartsInProduct(partsInProduct);
        selectedProductModify = original;
        Stage stage = (Stage)((Button)actionEvent.getSource()).getScene().getWindow();
        Object scene = FXMLLoader.load(getClass().getResource("/com/example/projectc482/Main Form.fxml"));
        stage.setScene(new Scene((Parent) scene));
        stage.show();

    }
    //updates selected product and partsinproduct list
    public void OnSaveButtonClick(ActionEvent actionEvent) {
        //sets selected product with new values
        selectedProductModify.setMax(Integer.parseInt(ModifyProductFormMainTFMax.getText()));
        selectedProductModify.setName(ModifyProductFormMainTFName.getText());
        selectedProductModify.setMin(Integer.parseInt(ModifyProductFormMainTFMin.getText()));
        selectedProductModify.setStock(Integer.parseInt(ModifyProductFormMainTFInv.getText()));
        selectedProductModify.setPrice(Double.parseDouble(ModifyProductFormMainTFPrice.getText()));
        //checks if values were inputted correctly
        if (selectedProductModify.getMax() < selectedProductModify.getMin()) {
            System.out.println("Check Max, Min, and Inventory values.");
        }
        else if (selectedProductModify.getStock() > selectedProductModify.getMax() || selectedProductModify.getStock() < selectedProductModify.getMin()) {
            System.out.println("Check Max, Min, and Inventory values.");
            return;
        }
        //must have parts in product to be viable
        if (partsInProduct.isEmpty()) {
            System.out.println("Product needs associated Parts.");
            return;
        }
        //closes modify priduct window and opens up main window controller
        Parent root = null;
        try {
            root = FXMLLoader.load(getClass().getResource("/com/example/projectc482/Main Form.fxml"));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        Scene scene = new Scene(root);
        Stage mainForm = (Stage) ((Node)actionEvent.getSource()).getScene().getWindow();
        mainForm.setScene(scene);
        mainForm.show();
        }
}

