package com.example.projectc482.Model;

public class Outsourced extends Part{
//    Will have companyName as a string, inheritance from part.java
    private String companyName;

    public Outsourced(int id, String name, double price, int stock, int min, int max, String companyName){
        super(id,name, price, stock, min, max);
        this.companyName = companyName;
    }


    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }
}
