package com.example.projectc482.Model;

public class InHouse extends Part{
//    Will have machineid as an int with inheritance from part.java
    private int machineID;

    public InHouse(int id, String name, double price, int stock, int min, int max, int machineID) {
        super (id,name, price, stock, min, max);
        this.machineID = machineID;
    }


    public int getMachineID() {
        return machineID;
    }

    public void setMachineID(int machineID) {
        this.machineID = machineID;
    }
}
