package com.example.projectc482.Model;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import java.util.ArrayList;
import java.util.List;
//class/model for creating the inventory of parts and products
public class Inventory {
    //    Will Have part and product list and output them, dependant of part.java and product.java
    //creates a part list and a method to add to the list
    public static ObservableList<Part> partInventory = FXCollections.observableArrayList();
    public static void addPart(Part part){
        partInventory.add(part);
    }
    // method called when getting a list of part ids for creating a unique id.
    public static List<Integer> getPartIDList(){
        List<Integer> partIDs = new ArrayList<>();
        for (int i = 0; i < partInventory.size(); i++){
            partIDs.add(partInventory.get(i).getId());

        }
        return partIDs;
    }
    //returns the partInventory list
    public static ObservableList<Part> getPartInventory(){
        return partInventory;
    }
    //used for searching part table on the main controller
    public static ObservableList searchParts(String partNameID) {
        //temp list for seeing matching parts
        ObservableList<Part> matchedParts = FXCollections.observableArrayList();
        //checks if empty to return all parts
        if(partNameID == "") {
            matchedParts = partInventory;
        }
        //checks to see if we are searching with ids
        else {
            if (Character.isDigit(partNameID.charAt(0))) {
                for (Part part : partInventory) {
                    String tempPartID = String.valueOf(part.getId());
                    if (tempPartID.equals(partNameID) || tempPartID.contains(partNameID)) {
                        matchedParts.add(part);
                    }
                }
            }
            //compares input to names in part inventory to return results that contain the inputted string
            else {
                for (Part part : partInventory) {
                    String tempPart = part.getName();
                    if (tempPart.contains(partNameID) || tempPart.toLowerCase().contains(partNameID) || tempPart.toUpperCase().contains(partNameID)) {
                        matchedParts.add(part);

                    }
                }
            }
        }
        //if the size of matched parts is 0 that means no parts were found.
        if (matchedParts.size() == 0){
            System.out.println("No parts found. Please try typing in another part or part ID.");
        }
        return matchedParts;
    }
    //creates a product inventory
    public static ObservableList<Product> productInventory = FXCollections.observableArrayList();
    //method called to add new products to product inventory
    public static void addProduct(Product product){
        productInventory.add(product);
    }
    //method returns current productInventory
    public static ObservableList<Product> getProductInventory(){
        return productInventory;
    }
    //Method does the same thing that the searchPart method does except for products.
    public static ObservableList searchProducts(String productNameID){
        //temp list for seeing matching products
        ObservableList<Product> matchedProducts = FXCollections.observableArrayList();
        //checks if empty to return all parts
        if(productNameID.equals("")) {
            matchedProducts = productInventory;
        }
        //checks to see if we are searching with ids
        else {
            if (Character.isDigit(productNameID.charAt(0))) {
                for (Product product : productInventory) {
                    String tempProductID = String.valueOf(product.getId());
                    if (tempProductID.equals(productNameID) || tempProductID.contains(productNameID)) {
                        matchedProducts.add(product);
                    }
                }
            }
            //compares input to names in product inventory to return results that contain the inputted string
            else if (Character.isAlphabetic(productNameID.charAt(0))){
                for (Product product : productInventory) {
                    String tempPart = product.getName();
                    if (tempPart.contains(productNameID) || tempPart.toLowerCase().contains(productNameID) || tempPart.toUpperCase().contains(productNameID)) {
                        matchedProducts.add(product);
                    }
                }
            }
        }
        //if the size of matched products is 0 that means no parts were found.
        if (matchedProducts.size() == 0){
            System.out.println("No product found. Please try typing in another product or product ID.");
        }
        return matchedProducts;
    }

    //Test Data

//    static {
//        addTestData();
//    }
//    public static void addTestData() {
//        Part handle = new Outsourced(1, "Handle", 1.00, 2, 2, 2, "HandleCo.");
//        Inventory.addPart(handle);
//        InHouse bell = new InHouse(2, "bell", 2.00, 4, 2, 5, 1);
//        Inventory.addPart(bell);
//        InHouse pipe = new InHouse(3, "pipe", 1.00, 45, 5, 50, 3);
//        Inventory.addPart(pipe);
//        InHouse tacoBell = new InHouse(12, "tacobell", 2.00, 4, 2, 5, 2);
//        Inventory.addPart(tacoBell);
//        Product handleBell = new Product(1,"HandleBell", 3.00, 2, 2, 6);
//        Inventory.addProduct(handleBell);
//        Product hanBell = new Product(2,"HanBell", 3.00, 4, 4, 6);
//        Inventory.addProduct(hanBell);
//        Product haBell = new Product(12,"HaBell", 3.00, 6, 4, 6);
//        Inventory.addProduct(haBell);
//    }

    //used to return product Ids list and generating new product ids.
    public static List<Integer> getProductIDList() {
        List<Integer> productIDs = new ArrayList<>();
        for (int i = 0; i < productInventory.size(); i++){
            productIDs.add(productInventory.get(i).getId());

        }
        return productIDs;
    }
}
