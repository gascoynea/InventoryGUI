package com.example.projectc482.controller;

import com.example.projectc482.Model.Inventory;
import com.example.projectc482.Model.Outsourced;
import com.example.projectc482.Model.Part;
import com.example.projectc482.Model.Product;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
//This class is for the add product window, which creates new product using the product mode/class.
public class AddProductFormController implements Initializable {
    public AnchorPane AddProductFormWindow;
    public TextField AddProductFormTFID;
    public TextField AddProductFormTFName;
    public TextField AddProductFormTFInventory;
    public TextField AddProductFormTFPrice;
    public TextField AddProductFormTFMax;
    public TextField AddProductFormTFMin;
    public TextField AddProductFormSearchIDName;
    public Button AddProductFormButtonCancel;
    public Button AddProductFormButtonSave;
    public Button AddProductFormButtonRemovePart;
    public Button AddProductFormButtonAdd;
    public TableView AddProductFormTableAddPart;
    public TableView AddProductFormTableRemovePart;
    public Label AddProductFormMainLabel;
    public Label AddProductFormLabelID;
    public Label AddProductFormLabelName;
    public Label AddProductFormLabelInventory;
    public Label AddProductFormLabelPrice;
    public Label AddProductFormLabelMax;
    public Label AddProductFormLabelMin;
    public TableColumn AddProductFormTableAddPartcolPartID;
    public TableColumn AddProductFormTableAddPartcolPartName;
    public TableColumn AddProductFormTableAddPartcolInvLevel;
    public TableColumn AddProductFormTableAddPartcolPriceCostperUnit;
    public TableColumn AddProductFormTableRemovePartcolPartID;
    public TableColumn AddProductFormTableRemovePartcolPartName;
    public TableColumn AddProductFormTableRemovePartcolInvLevel;
    public TableColumn AddProductFormTableRemovePartcolPriceCostperUnit;
    //using the data structures for temp storage.
    private ObservableList<Part> partsInProduct = FXCollections.observableArrayList();
    private int productID;
    private Product newProduct = null;
    //generates the product id by comparing it to already created products id and taking the next int available.
    //Also, populates the AddProductFormTableAddPart.
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        productID = 1;
        List<Integer> productIDs = Inventory.getProductIDList();
        while (productIDs.contains(productID)) {
            productID += 1;
        }
        AddProductFormTFID.setText(String.valueOf(productID));
        AddProductFormTableAddPart.setItems(Inventory.getPartInventory());

        AddProductFormTableAddPartcolPartID.setCellValueFactory(new PropertyValueFactory<>("id"));
        AddProductFormTableAddPartcolPartName.setCellValueFactory(new PropertyValueFactory<>("name"));
        AddProductFormTableAddPartcolInvLevel.setCellValueFactory(new PropertyValueFactory<>("stock"));
        AddProductFormTableAddPartcolPriceCostperUnit.setCellValueFactory(new PropertyValueFactory<>("price"));
    }
    //Allows the user to search for parts in the table.
    public void OnSearchPartTable(ActionEvent actionEvent) {
        String searchedPart = AddProductFormSearchIDName.getText();
        ObservableList partsFound = Inventory.searchParts(searchedPart);
        AddProductFormTableAddPart.setItems(partsFound);
    }
    //Checks if a part is selected if not throws error message.
    //if found part is added to a list of parts associated with the product.
    //repopulates the associated part list with the all the parts associated with the product
    //populates the associated part table.
    public void OnAddPartClick(ActionEvent actionEvent) {
        Part selectedProductAdd = (Part) AddProductFormTableAddPart.getSelectionModel().getSelectedItem();
        if(selectedProductAdd != null) {
            partsInProduct.add(selectedProductAdd);
            AddProductFormTableRemovePart.setItems(partsInProduct);
            AddProductFormTableRemovePartcolPartID.setCellValueFactory(new PropertyValueFactory<>("id"));
            AddProductFormTableRemovePartcolPartName.setCellValueFactory(new PropertyValueFactory<>("name"));
            AddProductFormTableRemovePartcolInvLevel.setCellValueFactory(new PropertyValueFactory<>("stock"));
            AddProductFormTableRemovePartcolPriceCostperUnit.setCellValueFactory(new PropertyValueFactory<>("price"));
        }
        else{
            System.out.println("Select a part to add to Associated Parts list.");
        }
    }
    //Allows user to remove products from the selected part on the associated part table.
    //also, removes the part from the associated parts in the partsInProduct list.
    public void OnRemoveAssociatedPartClick(ActionEvent actionEvent) {
        Part selectedProductRemove = (Part) AddProductFormTableRemovePart.getSelectionModel().getSelectedItem();
        if (selectedProductRemove != null) {
            partsInProduct.remove(selectedProductRemove);
            AddProductFormTableRemovePart.setItems(partsInProduct);
        }
        else{
            System.out.println("Select a part to remove.");
        }
    }
    //sets temp variables to what the Text Fields have been set.
    //Creates the Product object and goes back to the main window.
    public void OnSaveProductButton(ActionEvent actionEvent) {
        //setting variable to the correlating TF
        String inventory = (AddProductFormTFInventory.getText());
        String price = (AddProductFormTFPrice.getText());
        String name = AddProductFormTFName.getText();
        String max = (AddProductFormTFMax.getText());
        String min = (AddProductFormTFMin.getText());
        //checks to see if the user didn't input into the TF.
        //Also, checks to see if the inventory levels and Max/min levels are correctly inputted.
        if (name.equals("TypeName")){
            System.out.println("Input a new name.");
        } else if (price.equals("EnterPrice")) {
            System.out.println("Input a price.");
        } else if (inventory.equals("EnterInventoryLevel")) {
            System.out.println("Input inventory amount.");
        } else if (min.equals("EnterMin")) {
            System.out.println("Input a minimum stock amount.");
        } else if (max.equals("EnterMax")) {
            System.out.println("Input a maximum stock amount.");
        } else{
            int inventorynum = Integer.parseInt((AddProductFormTFInventory.getText()));
            int maxnum = Integer.parseInt((AddProductFormTFMax.getText()));
            int minnum = Integer.parseInt((AddProductFormTFMin.getText()));
            if(inventorynum > maxnum){
                System.out.println("Inventory stock is greater than the maximum allowed.");
            }
            else if(inventorynum < minnum){
                System.out.println("Inventory stock is less than the minimum allowed.");
            }
            String namenew = AddProductFormTFName.getText();
            //checks to see if name is already taken by another product.
            for (Product product : Inventory.productInventory){
                if (product.getName().equals(namenew)){
                    System.out.println("Name in use.");
                }
            }
            //changes the data in the text fields to their correct data types
            //Creates the product and adds associated parts to its list.
            Double pricenum = Double.valueOf((AddProductFormTFPrice.getText()));
            newProduct = new Product(productID,namenew,pricenum,inventorynum, minnum, maxnum);
            newProduct.setPartsInProduct(partsInProduct);
            Inventory.addProduct(newProduct);
            //Opens the main form.
            Parent root = null;
            try {
                root = FXMLLoader.load(getClass().getResource("/com/example/projectc482/Main Form.fxml"));
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            Scene scene = new Scene(root);
            Stage mainForm = (Stage) ((Node)actionEvent.getSource()).getScene().getWindow();
            mainForm.setScene(scene);
            mainForm.show();

        }
    }
    //Closes the Add Product menu and opens the main window.
    public void OnCancelButtonClick(ActionEvent actionEvent) throws IOException {
        Stage stage = (Stage)((Button)actionEvent.getSource()).getScene().getWindow();
        Object scene = FXMLLoader.load(getClass().getResource("/com/example/projectc482/Main Form.fxml"));
        stage.setScene(new Scene((Parent) scene));
        stage.show();
    }
}
