package com.example.projectc482.controller;

import com.example.projectc482.Model.InHouse;
import com.example.projectc482.Model.Inventory;
import com.example.projectc482.Model.Outsourced;
import com.example.projectc482.Model.Part;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
//This class changes already created parts using methods within itself and updates the Part list in Inventory class.
public class ModifyPartFormController implements Initializable {
    public AnchorPane ModifyPartFormWindow;
    public Button ModifyPartFormButtonCancel;
    public Button ModifyPartFormButtonSave;
    public Label ModifyPartFormLabelModifyPart;
    public RadioButton ModifyPartFormRadInHouse;
    public RadioButton ModifyPartFormRadOutsourced;
    public Label ModifyPartFormLabelID;
    public Label ModifyPartFormLabelName;
    public Label ModifyPartFormLabelInventory;
    public Label ModifyPartFormLabelPriceCost;
    public Label ModifyPartFormLabelMax;
    public Label ModifyPartFormLabelMachID;
    public Label ModifyPartFormLabelMin;
    public TextField ModifyPartFormTFID;
    public TextField ModifyPartFormTFMin;
    public TextField ModifyPartFormTFName;
    public TextField ModifyPartFormTFInventory;
    public TextField ModifyPartFormTFPriceCost;
    public TextField ModifyPartFormTFMax;
    public TextField ModifyPartFormTFMachID;
    //creates a public variable of the part object to be manipulated.
    public Part selectedPartModify;
    public void initialize(URL url, ResourceBundle resourceBundle) {
    }
    //sets the ModifyPartFormLabelMachID based on radio button selected
    public void InHouseSelected() {
        ModifyPartFormLabelMachID.setText("Machine ID");
        InHouse temp = null;
    }
    //sets the ModifyPartFormLabelMachID based on radio button selected
    public void OutSourcedSelected() {
        ModifyPartFormLabelMachID.setText("Company Name");
        Outsourced temp = null;
    }
    //Gets all the information from the part to be modified so we can fill out all text fields.
    public void setPartToModify(Part selectedPartModify) {
        //Grabs each variable in the part object that was selected using methods from the Part Class.
        //sets the Text fields with the variables.
        this.selectedPartModify = selectedPartModify;
        int id = selectedPartModify.getId();
        String name = selectedPartModify.getName();
        int inventory = selectedPartModify.getStock();
        Double price = selectedPartModify.getPrice();
        int max = selectedPartModify.getMax();
        int min = selectedPartModify.getMin();
        ModifyPartFormTFID.setText(String.valueOf(id));
        ModifyPartFormTFInventory.setText(String.valueOf(inventory));
        ModifyPartFormTFMin.setText(String.valueOf(min));
        ModifyPartFormTFMax.setText(String.valueOf(max));
        ModifyPartFormTFName.setText(name);
        ModifyPartFormTFPriceCost.setText(String.valueOf(price));
        //sets the machine name or company name dependent if part is in house or out sourced.
        if (selectedPartModify instanceof InHouse) {
            ModifyPartFormRadInHouse.setSelected(true);
            int machineID = ((InHouse) selectedPartModify).getMachineID();
            ModifyPartFormTFMachID.setText(String.valueOf(machineID));
        } else {
            ModifyPartFormRadOutsourced.setSelected(true);
            String companyName = ((Outsourced) selectedPartModify).getCompanyName();
            ModifyPartFormTFMachID.setText(companyName);
            ModifyPartFormLabelMachID.setText("Company Name");
        }
    }
    //sets the values in the part object that is being modified.
    public void onCLick(ActionEvent actionEvent) {
        //uses the set method from the Part class to update the selected part
        selectedPartModify.setMax(Integer.parseInt(ModifyPartFormTFMax.getText()));
        selectedPartModify.setName(ModifyPartFormTFName.getText());
        selectedPartModify.setMin(Integer.parseInt(ModifyPartFormTFMin.getText()));
        selectedPartModify.setStock(Integer.parseInt(ModifyPartFormTFInventory.getText()));
        selectedPartModify.setPrice(Double.parseDouble(ModifyPartFormTFPriceCost.getText()));
        //makes sure the variables were inputted correctly.
        if (selectedPartModify.getMax() < selectedPartModify.getMin()) {
            System.out.println("Check Max, Min, and Inventory values.");
        } else if (selectedPartModify.getStock() > selectedPartModify.getMax() || selectedPartModify.getStock() < selectedPartModify.getMin()) {
            System.out.println("Check Max, Min, and Inventory values.");
        } else{
            if(selectedPartModify instanceof InHouse){
                try {
                    ((InHouse) selectedPartModify).setMachineID(Integer.parseInt(ModifyPartFormTFMachID.getText()));
                } catch (NumberFormatException e) {
                    System.out.println(e.getMessage());
                    System.out.println("Macahine ID needs to be an Integer.");
                }
            }
            //exits the current form and opens the main controller window.
            Parent root = null;
            try {
                root = FXMLLoader.load(getClass().getResource("/com/example/projectc482/Main Form.fxml"));
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            Scene scene = new Scene(root);
            Stage mainForm = (Stage) ((Node)actionEvent.getSource()).getScene().getWindow();
            mainForm.setScene(scene);
            mainForm.show();
        }
    }
    //exits the current form and opens the main controller window.
    public void OnCancelClick(ActionEvent actionEvent) {
        Parent root = null;
        try {
            root = FXMLLoader.load(getClass().getResource("/com/example/projectc482/Main Form.fxml"));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        Scene scene = new Scene(root);
        Stage mainForm = (Stage) ((Node)actionEvent.getSource()).getScene().getWindow();
        mainForm.setScene(scene);
        mainForm.show();
    }
}