package com.example.projectc482.controller;

import com.example.projectc482.Model.*;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventType;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.stage.Window;
import javafx.stage.WindowEvent;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
//This class uses methods within it to create part objects using the Part class
public class AddPartFormController implements Initializable {
    public AnchorPane AddPartWindow;
    public Button AddPartCancelButton;
    public Button AddPartSaveButton;
    public Label AddPartLabel;
    public RadioButton AddPartRadInHouse;
    public RadioButton AddPartRadOutSource;
    public Label AddPartLabelID;
    public Label AddPartLabelName;
    public Label AddPartLabelInventory;
    public Label AddPartLabelPriceCost;
    public Label AddPartLabelMax;
    public Label AddPartLabelMachID;
    public Label AddPartLabelMin;
    public TextField AddPartTextFieldID;
    public TextField AddPartTextFieldMin;
    public TextField AddPartTextFieldName;
    public TextField AddPartTextFieldinventory;
    public TextField AddPartTextFieldPriceCost;
    public TextField AddPartTextFieldMax;
    public TextField AddPartTextFieldMachID;

    //generates a new part id by checking all parts and uses the next immediate integer.
    //also, populates the part id Text Field.
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        int partID = 1;
        List<Integer> partsIDs = Inventory.getPartIDList();
        while (partsIDs.contains(partID)) {
            partID += 1;
        }
        AddPartTextFieldID.setText(String.valueOf(partID));
    }
    //Changes the AddPartLabelMachID to MachineID  if the radio in house button is selected.
    public void InHouseSelected(ActionEvent actionEvent) {
        AddPartLabelMachID.setText("Machine ID");
    }
    //Changes the AddPartLabelMachID to Company name  if the radio outsource button is selected.
    public void OutSourcedSelected(ActionEvent actionEvent) {
        AddPartLabelMachID.setText("Company Name");
    }
    //Cancel button closes the add part window and opens up the main controller window.
    public void OnCancelPartButtonClick(ActionEvent actionEvent) throws IOException {
        Parent root = null;
        try {
            root = FXMLLoader.load(getClass().getResource("/com/example/projectc482/Main Form.fxml"));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        Scene scene = new Scene(root);
        Stage mainForm = (Stage) ((Node)actionEvent.getSource()).getScene().getWindow();
        mainForm.setScene(scene);
        mainForm.show();
    }
    //creates the part and checks fields to make sure they are properly filled out and adds the part to the part list in the Inventory class.
    public void OnSavePartButtonClick(ActionEvent actionEvent) {
        int id = Integer.parseInt(AddPartTextFieldID.getText());
        String name = AddPartTextFieldName.getText();
        //checks to see if name for part is already in use
        for (Part part : Inventory.partInventory){
            if (part.getName().equals(name)){
                System.out.println("Name in use.");
                return;
            }
        }
        //sets variables to be used to create the part object
        double price = Double.parseDouble(AddPartTextFieldPriceCost.getText());
        int stock = Integer.parseInt(AddPartTextFieldinventory.getText());
        int min = Integer.parseInt(AddPartTextFieldMin.getText());
        int max = Integer.parseInt(AddPartTextFieldMax.getText());
        //checks to make sure min, max, and inventory input works.
        if(stock < min || stock > max){
            System.out.println("Stock level is either higher than the max acceptable or is either lower than the min acceptable.");
            return;
        } else if (min > max) {
            System.out.println("minimum is higher than maximum.");
            return;
        }
        //creates part as either inhouse or outsourced.
        if (AddPartRadInHouse.isSelected()) {
            int machineID = Integer.parseInt(AddPartTextFieldMachID.getText());
            Part temp = new InHouse(id, name, price, stock, min, max, machineID);
            Inventory.addPart(temp);
        }
        else {
            String machineID = AddPartTextFieldMachID.getText();
            Part temp = new Outsourced(id, name, price, stock, min, max, machineID);
            Inventory.addPart(temp);
        }
        //closes this window and opens up the main controller window.
        Parent root = null;
        try {
            root = FXMLLoader.load(getClass().getResource("/com/example/projectc482/Main Form.fxml"));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        Scene scene = new Scene(root);
        Stage mainForm = (Stage) ((Node)actionEvent.getSource()).getScene().getWindow();
        mainForm.setScene(scene);
        mainForm.show();
    }
}
