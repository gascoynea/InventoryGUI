
package com.example.projectc482.controller;

import com.example.projectc482.Model.Inventory;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
//Main class of the app.
public class Main extends Application {
    @Override
//    Initializes the program and opens up the Main Controller Window.
//    No logical/runtime errors.
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("/com/example/projectc482/Main Form.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 1050, 400);
        stage.setTitle("Inventory");
        stage.setScene(scene);
        stage.show();
    }
//    Launches the program.
    public static void main(String[] args) {
        launch();
    }
}
